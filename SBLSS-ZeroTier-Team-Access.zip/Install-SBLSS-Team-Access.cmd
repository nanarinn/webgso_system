@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SBLSS-Team-Access.ps1"
if errorlevel 1 (
    echo.
    echo Installation failed. Please check the message above.
    pause
    exit /b 1
)
echo.
echo Setup finished. Press any key to close this window.
pause >nul
