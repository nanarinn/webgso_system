SBLSS access for team members through ZeroTier

1. Extract the whole ZIP to a folder on your Windows computer.
2. Join the same ZeroTier network and wait until the device is Authorized.
3. Double-click Install-SBLSS-Team-Access.cmd and approve the Windows Administrator prompt.
4. The installer trusts the SBLSS public certificate, maps sblss-lan.local to
   the ZeroTier web-server address 10.122.147.3, and opens
   https://sblss-lan.local:8088/login.
5. Sign in with your own SAE Microsoft account. An SBLSS administrator must
   approve your access in User Management before you can use the system.

Keep ZeroTier, the host computer and the SBLSS application running. The web
server must retain the managed ZeroTier address 10.122.147.3. If it changes,
ask the SBLSS administrator for an updated package.

Certificate SHA-1 thumbprint:
8F8E4FFFCCD308B03ED466228E121A57E91EA89D

This package contains only the public certificate. It has no private key or password.
