$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $PSCommandPath
$isAdministrator = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdministrator) {
    try {
        $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        $elevated = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $arguments -Wait -PassThru
        exit $elevated.ExitCode
    }
    catch {
        Write-Error "Administrator approval is required: $($_.Exception.Message)"
        exit 1
    }
}

try {
    $certificatePath = Join-Path $folder 'sblss-lan.cer'
    $certificate = New-Object Security.Cryptography.X509Certificates.X509Certificate2($certificatePath)
    if ($certificate.Thumbprint -ne '8F8E4FFFCCD308B03ED466228E121A57E91EA89D' -or
        $certificate.NotAfter -le (Get-Date)) {
        throw 'The SBLSS certificate is different from the verified certificate or has expired.'
    }
    & (Join-Path $folder 'trust-sblss-lan-certificate.ps1') `
        -IPAddress '10.122.147.3' `
        -HostName 'sblss-lan.local' `
        -CertificatePath $certificatePath
    Start-Process 'https://sblss-lan.local:8088/login'
}
catch {
    Write-Error $_
    exit 1
}
